#include "Command/ClassController.h"

int main() {
  ClassController* controller = new ClassController();
  delete controller;
  return 0;
}