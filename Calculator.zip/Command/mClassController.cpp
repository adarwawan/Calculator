#include "ClassController.h"

using namespace std;

int main() {
  ClassController controller;
  return 0;
}
