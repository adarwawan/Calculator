#include <cstdio>
#include "Extension.h"

using namespace std;

int main() {
  printf("Infix %d \n", Extension::Infix);
  printf("NumberMode %d\n", Extension::NumberMode);
  printf("ArabMode %d\n", Extension::ArabMode);
  return 0;
}