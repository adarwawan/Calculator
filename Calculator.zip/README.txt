Kelompok /* */
Mentor : Sonny Lazuardi H. (13511029)
Anggota :
Luqman A. Siswanto (13513024)
Muhammad Aodyra Khaidir (13513063)
Wiwit Rifa'i (13513073)
Ahmad Darmawan (13513096)


Pembagian Kerja Kelas:
1. ClassController	Luqman A. Siswanto
2. Log			Luqman A. Siswanto
3. Logger		Luqman A. Siswanto
4. Reader		Luqman A. Siswanto
5. Saver		Ahmad Darmawan
6. Expression		Wiwit Rifai
7. Equation		Wiwit Rifai
8. EquationException	Wiwit Rifai
9. Extension		Luqman A. Siswanto
10. Stack		Wiwit Rifai
11. Vector		Luqman A. Siswanto
12. Logic		Ahmad Darmawan
13. Number (abc)	Muhammad Aodyra Khaidir
14. NumberArab		Muhammad Aodyra Khaidir
15. NumberRomawi	Muhammad Aodyra Khaidir
16. Token		Ahmad Darmawan